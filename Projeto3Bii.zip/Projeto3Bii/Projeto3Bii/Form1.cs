using System.Drawing;

/*Colegio T�cnico Ant�nio Teixeira Fernandes (Univap)
 * Curso T�cnico em Inform�tica - Data de Entrega: 11 / 09 / 2024
 * Autores do Projeto: Lucas Lopes Sincerr�
 *                     Matheus Ver�ssimo Gonzalez
 * Turma: 3F
 * Atividade Proposta em aula
 * Observa��o: < colocar se houver>
 * 
 * 
 * ******************************************************************/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Drawing.Imaging;
using System.Windows.Forms;
using System.Numerics;

namespace Projeto3Bii
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            button1.Enabled = false;
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox2.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox3.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox4.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox5.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox6.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox7.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox8.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox9.SizeMode = PictureBoxSizeMode.StretchImage;
            const string Im = "C:\\Imagens\\Im.jpg";
            const string Aviao = "C:\\Imagens\\Aviao2.jpg";
            const string Balao = "C:\\Imagens\\Balao.jpg";
            const string Homem = "C:\\Imagens\\homem.jpg";
            const string AMesclado = "C:\\Imagens\\Mesclado.jpg";
            ProjetoImagens Jun��oImagem = new ProjetoImagens();
            Jun��oImagem.TransformarBit(Im);
            Jun��oImagem.Mesclar(Aviao, 100, 10);
            Jun��oImagem.Mesclar(Balao, 450, 10);
            Jun��oImagem.Mesclar(Homem, 300, 500); 
            Jun��oImagem.SaveE(AMesclado);
            pictureBox1.Load(AMesclado);
            const string Cinza = "C:\\Imagens\\Cinza.jpg";
            ProjetoImagens processadorCinza = new ProjetoImagens();
            Jun��oImagem.TransformarBit(AMesclado);
            Jun��oImagem.Gray();
            Jun��oImagem.SaveE(Cinza);
            pictureBox2.Load(Cinza);
            const string PretoeBranco = "C:\\Imagens\\PretoBranco.jpg";
            ProjetoImagens processadorPb = new ProjetoImagens();
            Jun��oImagem.TransformarBit(Cinza);
            Jun��oImagem.Thresholding();
            Jun��oImagem.SaveE(PretoeBranco);
            pictureBox3.Load(PretoeBranco);
            const string Brilho = "C:\\Imagens\\Brilhante.jpg";
            ProjetoImagens processadorBrilho = new ProjetoImagens();
            Jun��oImagem.TransformarBit(AMesclado);
            Jun��oImagem.MaisClaro();
            Jun��oImagem.SaveE(Brilho);
            pictureBox4.Load(Brilho);
            const string Rotacionado = "C:\\Imagens\\Rodado.jpg";
            ProjetoImagens processadorRoda = new ProjetoImagens();
            Jun��oImagem.TransformarBit(Cinza);
            Jun��oImagem.Rotacionar();
            Jun��oImagem.SaveE(Rotacionado);
            pictureBox5.Load(Rotacionado);

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            
        }
    }

    class ProjetoImagens
    {
        Bitmap bitmap;
        string nomeArquivo;

        public Color cores(int r, int g, int b)
        {
            return Color.FromArgb(r, g, b);
        }
        public Color CorBrilhante(Color corOriginal)
        {
            const int DB = 85;

            int novoR = corOriginal.R + DB;
            if (novoR > 255) novoR = 255;

            int novoG = corOriginal.G + DB;
            if (novoG > 255) novoG = 255;

            int novoB = corOriginal.B + DB;
            if (novoB > 255) novoB = 255;

            return Color.FromArgb(corOriginal.A, novoR, novoG, novoB);
        }
        

        public void MaisClaro()
        {
            for (int x = 0; x <= bitmap.Width - 1; x++)
                for (int y = 0; y <= bitmap.Height - 1; y++)
                {
                    Color corOriginal = bitmap.GetPixel(x, y);
                    bitmap.SetPixel(x, y, CorBrilhante(corOriginal));
                }
        }
        public void TransformarBit(string Arquivo)
        {
            this.nomeArquivo = Arquivo;
            bitmap = new Bitmap(Arquivo);
        }

        public void SaveE(string AMesclado)
        {
            this.bitmap.Save(AMesclado, ImageFormat.Jpeg);
        }

        private int GrayLevel(Color color)
        {
            double result = color.R * 0.30 + color.G * 0.59 + color.B * 0.11;
            int g = (int)(result + 0.5);
            return g;
        }

        public void Gray()
        {
            for (int x = 0; x <= bitmap.Width - 1; x++)
                for (int y = 0; y <= bitmap.Height - 1; y++)
                {
                    int g = GrayLevel(bitmap.GetPixel(x, y));
                    int a = bitmap.GetPixel(x, y).A;
                    bitmap.SetPixel(x, y, Color.FromArgb(a, g, g, g));
                }
        }


        public void Thresholding()
        {
            for (int x = 0; x <= bitmap.Width - 1; x++)
                for (int y = 0; y <= bitmap.Height - 1; y++)
                    if (GrayLevel(bitmap.GetPixel(x, y)) <= 126) //codigo 116
                        bitmap.SetPixel(x, y, Color.FromArgb(0, 0, 0));  
                    else
                        bitmap.SetPixel(x, y, Color.FromArgb(255, 255, 255));  
        }


        public void Rotacionar()
        {
            int larg = bitmap.Width;
            int alt = bitmap.Height;
            Bitmap bmprotacionado = new Bitmap(alt, larg);
            for (int x = 0; x <= larg - 1; x++)
                for (int y = 0; y <= alt - 1; y++)
                {
                    Color cor = bitmap.GetPixel(x, y);
                    bmprotacionado.SetPixel(y, larg - 1 - x, cor);
                }
            bitmap = bmprotacionado;
        }

        public void Mesclar(string Desenho, int x0, int y0)
        {
            Bitmap bitmapD = new Bitmap(Desenho);
            int T = 23;
            int larg = bitmapD.Width;
            int alt = bitmapD.Height;
            Color RemovFundo = bitmapD.GetPixel(0, 0);

            for (int x = 0; x < larg - 1; x++)
            {
                for (int y = 0; y < alt - 1; y++)
                {
                    int g = GrayLevel(bitmapD.GetPixel(x, y));
                    int DeltaR = Math.Abs(bitmapD.GetPixel(x, y).R - RemovFundo.R);
                    int DeltaG = Math.Abs(bitmapD.GetPixel(x, y).G - RemovFundo.G);
                    int DeltaB = Math.Abs(bitmapD.GetPixel(x, y).B - RemovFundo.B);

                    bool remov = (DeltaR < T) && (DeltaG < T) && (DeltaB < T);

                    if (!remov)
                    {
                        this.bitmap.SetPixel(x0 + x, y0 + y, bitmapD.GetPixel(x, y));
                    }
                }
            }
        }

    }

}
     